package com.getcapacitor;

/* JADX INFO: loaded from: classes.dex */
public interface RouteProcessor {
    ProcessedRoute process(String str, String str2);
}
