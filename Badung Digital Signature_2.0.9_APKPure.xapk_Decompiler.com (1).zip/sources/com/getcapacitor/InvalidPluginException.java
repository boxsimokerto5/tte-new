package com.getcapacitor;

/* JADX INFO: loaded from: classes.dex */
class InvalidPluginException extends Exception {
    public InvalidPluginException(String str) {
        super(str);
    }
}
