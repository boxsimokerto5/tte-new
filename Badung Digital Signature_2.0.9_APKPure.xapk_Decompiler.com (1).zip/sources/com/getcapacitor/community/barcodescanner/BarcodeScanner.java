package com.getcapacitor.community.barcodescanner;

import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.util.Log;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import androidx.activity.result.ActivityResult;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.ResultPoint;
import com.journeyapps.barcodescanner.BarcodeCallback;
import com.journeyapps.barcodescanner.BarcodeResult;
import com.journeyapps.barcodescanner.BarcodeView;
import com.journeyapps.barcodescanner.DefaultDecoderFactory;
import com.journeyapps.barcodescanner.camera.CameraSettings;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.json.JSONException;

/* JADX INFO: loaded from: classes.dex */
@CapacitorPlugin(permissions = {@Permission(alias = BarcodeScanner.PERMISSION_ALIAS_CAMERA, strings = {BarcodeScanner.PERMISSION_NAME})})
public class BarcodeScanner extends Plugin implements BarcodeCallback {
    private static final String ASKED = "asked";
    private static final String DENIED = "denied";
    private static final String GRANTED = "granted";
    private static final String NEVER_ASKED = "neverAsked";
    public static final String PERMISSION_ALIAS_CAMERA = "camera";
    private static final String PERMISSION_NAME = "android.permission.CAMERA";
    private static final String PREFS_PERMISSION_FIRST_TIME_ASKING = "PREFS_PERMISSION_FIRST_TIME_ASKING";
    private static final String TAG_PERMISSION = "permission";
    private static final Map<String, BarcodeFormat> supportedFormats = supportedFormats();
    private BarcodeView mBarcodeView;
    private JSObject savedReturnObject;
    private boolean isScanning = false;
    private boolean shouldRunScan = false;
    private boolean didRunCameraSetup = false;
    private boolean didRunCameraPrepare = false;
    private boolean isBackgroundHidden = false;
    private boolean isTorchOn = false;
    private boolean scanningPaused = false;
    private String lastScanResult = null;

    @Override // com.journeyapps.barcodescanner.BarcodeCallback
    public void possibleResultPoints(List<ResultPoint> list) {
    }

    private static Map<String, BarcodeFormat> supportedFormats() {
        HashMap map = new HashMap();
        map.put("UPC_A", BarcodeFormat.UPC_A);
        map.put("UPC_E", BarcodeFormat.UPC_E);
        map.put("UPC_EAN_EXTENSION", BarcodeFormat.UPC_EAN_EXTENSION);
        map.put("EAN_8", BarcodeFormat.EAN_8);
        map.put("EAN_13", BarcodeFormat.EAN_13);
        map.put("CODE_39", BarcodeFormat.CODE_39);
        map.put("CODE_93", BarcodeFormat.CODE_93);
        map.put("CODE_128", BarcodeFormat.CODE_128);
        map.put("CODABAR", BarcodeFormat.CODABAR);
        map.put("ITF", BarcodeFormat.ITF);
        map.put("AZTEC", BarcodeFormat.AZTEC);
        map.put("DATA_MATRIX", BarcodeFormat.DATA_MATRIX);
        map.put("MAXICODE", BarcodeFormat.MAXICODE);
        map.put("PDF_417", BarcodeFormat.PDF_417);
        map.put("QR_CODE", BarcodeFormat.QR_CODE);
        map.put("RSS_14", BarcodeFormat.RSS_14);
        map.put("RSS_EXPANDED", BarcodeFormat.RSS_EXPANDED);
        return Collections.unmodifiableMap(map);
    }

    private boolean hasCamera() {
        return getActivity().getPackageManager().hasSystemFeature("android.hardware.camera.any");
    }

    private void setupCamera(final String str) {
        getActivity().runOnUiThread(new Runnable() { // from class: com.getcapacitor.community.barcodescanner.BarcodeScanner$$ExternalSyntheticLambda1
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$setupCamera$0(str);
            }
        });
        this.didRunCameraSetup = true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Type inference fix 'apply assigned field type' failed
    java.lang.UnsupportedOperationException: ArgType.getObject(), call class: class jadx.core.dex.instructions.args.ArgType$UnknownArg
    	at jadx.core.dex.instructions.args.ArgType.getObject(ArgType.java:593)
    	at jadx.core.dex.attributes.nodes.ClassTypeVarsAttr.getTypeVarsMapFor(ClassTypeVarsAttr.java:35)
    	at jadx.core.dex.nodes.utils.TypeUtils.replaceClassGenerics(TypeUtils.java:177)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.insertExplicitUseCast(FixTypesVisitor.java:397)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.tryFieldTypeWithNewCasts(FixTypesVisitor.java:359)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.applyFieldType(FixTypesVisitor.java:309)
    	at jadx.core.dex.visitors.typeinference.FixTypesVisitor.visit(FixTypesVisitor.java:94)
     */
    public /* synthetic */ void lambda$setupCamera$0(String str) {
        this.mBarcodeView = new BarcodeView(getActivity());
        CameraSettings cameraSettings = new CameraSettings();
        cameraSettings.setRequestedCameraId("front".equals(str) ? 1 : 0);
        cameraSettings.setContinuousFocusEnabled(true);
        this.mBarcodeView.setCameraSettings(cameraSettings);
        ((ViewGroup) this.bridge.getWebView().getParent()).addView(this.mBarcodeView, new FrameLayout.LayoutParams(-2, -2));
        this.bridge.getWebView().bringToFront();
        this.mBarcodeView.resume();
    }

    private void dismantleCamera() {
        getActivity().runOnUiThread(new Runnable() { // from class: com.getcapacitor.community.barcodescanner.BarcodeScanner$$ExternalSyntheticLambda2
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$dismantleCamera$1();
            }
        });
        this.isScanning = false;
        this.didRunCameraSetup = false;
        this.didRunCameraPrepare = false;
        if (getSavedCall() == null || this.shouldRunScan) {
            return;
        }
        freeSavedCall();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$dismantleCamera$1() {
        BarcodeView barcodeView = this.mBarcodeView;
        if (barcodeView != null) {
            barcodeView.pause();
            this.mBarcodeView.stopDecoding();
            ((ViewGroup) this.bridge.getWebView().getParent()).removeView(this.mBarcodeView);
            this.mBarcodeView = null;
        }
    }

    private void _prepare(PluginCall pluginCall) {
        dismantleCamera();
        setupCamera(pluginCall.getString("cameraDirection", "back"));
        this.didRunCameraPrepare = true;
        if (this.shouldRunScan) {
            scan();
        }
    }

    private void destroy() {
        showBackground();
        dismantleCamera();
        setTorch(false);
    }

    private void configureCamera() {
        getActivity().runOnUiThread(new Runnable() { // from class: com.getcapacitor.community.barcodescanner.BarcodeScanner$$ExternalSyntheticLambda7
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$configureCamera$2();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$configureCamera$2() {
        PluginCall savedCall = getSavedCall();
        if (savedCall == null || this.mBarcodeView == null) {
            Log.d("scanner", "Something went wrong with configuring the BarcodeScanner.");
            return;
        }
        DefaultDecoderFactory defaultDecoderFactory = new DefaultDecoderFactory(null, null, null, 2);
        if (savedCall.hasOption("targetedFormats")) {
            JSArray array = savedCall.getArray("targetedFormats");
            ArrayList arrayList = new ArrayList();
            if (array != null && array.length() > 0) {
                for (int i = 0; i < array.length(); i++) {
                    try {
                        BarcodeFormat barcodeFormat = supportedFormats.get(array.getString(i));
                        if (barcodeFormat != null) {
                            arrayList.add(barcodeFormat);
                        }
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
            if (arrayList.size() > 0) {
                defaultDecoderFactory = new DefaultDecoderFactory(arrayList, null, null, 2);
            } else {
                Log.d("scanner", "The property targetedFormats was not set correctly.");
            }
        }
        this.mBarcodeView.setDecoderFactory(defaultDecoderFactory);
    }

    private void scan() {
        if (!this.didRunCameraPrepare) {
            if (hasCamera()) {
                if (!hasPermission(PERMISSION_NAME)) {
                    Log.d("scanner", "No permission to use camera. Did you request it yet?");
                    return;
                } else {
                    this.shouldRunScan = true;
                    _prepare(getSavedCall());
                    return;
                }
            }
            return;
        }
        this.didRunCameraPrepare = false;
        this.shouldRunScan = false;
        configureCamera();
        getActivity().runOnUiThread(new Runnable() { // from class: com.getcapacitor.community.barcodescanner.BarcodeScanner$$ExternalSyntheticLambda5
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$scan$3(this);
            }
        });
        hideBackground();
        this.isScanning = true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$scan$3(BarcodeCallback barcodeCallback) {
        if (this.mBarcodeView != null) {
            PluginCall savedCall = getSavedCall();
            if (savedCall != null && savedCall.isKeptAlive()) {
                this.mBarcodeView.decodeContinuous(barcodeCallback);
            } else {
                this.mBarcodeView.decodeSingle(barcodeCallback);
            }
        }
    }

    private void hideBackground() {
        getActivity().runOnUiThread(new Runnable() { // from class: com.getcapacitor.community.barcodescanner.BarcodeScanner$$ExternalSyntheticLambda3
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$hideBackground$4();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$hideBackground$4() {
        this.bridge.getWebView().setBackgroundColor(0);
        this.bridge.getWebView().loadUrl("javascript:document.documentElement.style.backgroundColor = 'transparent';void(0);");
        this.isBackgroundHidden = true;
    }

    private void showBackground() {
        getActivity().runOnUiThread(new Runnable() { // from class: com.getcapacitor.community.barcodescanner.BarcodeScanner$$ExternalSyntheticLambda4
            @Override // java.lang.Runnable
            public final void run() {
                this.f$0.lambda$showBackground$5();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showBackground$5() {
        this.bridge.getWebView().setBackgroundColor(-1);
        this.bridge.getWebView().loadUrl("javascript:document.documentElement.style.backgroundColor = '';void(0);");
        this.isBackgroundHidden = false;
    }

    @Override // com.journeyapps.barcodescanner.BarcodeCallback
    public void barcodeResult(BarcodeResult barcodeResult) {
        JSObject jSObject = new JSObject();
        if (barcodeResult.getText() != null) {
            jSObject.put("hasContent", true);
            jSObject.put("content", barcodeResult.getText());
            jSObject.put("format", barcodeResult.getBarcodeFormat().name());
        } else {
            jSObject.put("hasContent", false);
        }
        PluginCall savedCall = getSavedCall();
        if (savedCall != null) {
            if (savedCall.isKeptAlive()) {
                if (this.scanningPaused || barcodeResult.getText() == null || barcodeResult.getText().equals(this.lastScanResult)) {
                    return;
                }
                this.lastScanResult = barcodeResult.getText();
                savedCall.resolve(jSObject);
                return;
            }
            savedCall.resolve(jSObject);
            destroy();
            return;
        }
        destroy();
    }

    @Override // com.getcapacitor.Plugin
    public void handleOnPause() {
        BarcodeView barcodeView = this.mBarcodeView;
        if (barcodeView != null) {
            barcodeView.pause();
        }
    }

    @Override // com.getcapacitor.Plugin
    public void handleOnResume() {
        BarcodeView barcodeView = this.mBarcodeView;
        if (barcodeView != null) {
            barcodeView.resume();
        }
    }

    @PluginMethod
    public void prepare(PluginCall pluginCall) {
        _prepare(pluginCall);
        pluginCall.resolve();
    }

    @PluginMethod
    public void hideBackground(PluginCall pluginCall) {
        hideBackground();
        pluginCall.resolve();
    }

    @PluginMethod
    public void showBackground(PluginCall pluginCall) {
        showBackground();
        pluginCall.resolve();
    }

    @PluginMethod
    public void startScan(PluginCall pluginCall) {
        saveCall(pluginCall);
        scan();
    }

    @PluginMethod
    public void stopScan(PluginCall pluginCall) {
        Boolean bool;
        if (pluginCall.hasOption("resolveScan") && getSavedCall() != null && (bool = pluginCall.getBoolean("resolveScan", false)) != null && bool.booleanValue()) {
            JSObject jSObject = new JSObject();
            jSObject.put("hasContent", false);
            getSavedCall().resolve(jSObject);
        }
        destroy();
        pluginCall.resolve();
    }

    @PluginMethod(returnType = PluginMethod.RETURN_CALLBACK)
    public void startScanning(PluginCall pluginCall) {
        pluginCall.setKeepAlive(true);
        this.lastScanResult = null;
        saveCall(pluginCall);
        this.scanningPaused = false;
        scan();
    }

    @PluginMethod
    public void pauseScanning(PluginCall pluginCall) {
        this.scanningPaused = true;
        pluginCall.resolve();
    }

    @PluginMethod
    public void resumeScanning(PluginCall pluginCall) {
        this.lastScanResult = null;
        this.scanningPaused = false;
        pluginCall.resolve();
    }

    void _checkPermission(PluginCall pluginCall, boolean z) {
        this.savedReturnObject = new JSObject();
        if (getPermissionState(PERMISSION_ALIAS_CAMERA) == PermissionState.GRANTED) {
            this.savedReturnObject.put(GRANTED, true);
        } else {
            boolean zIsPermissionFirstTimeAsking = isPermissionFirstTimeAsking(PERMISSION_NAME);
            if (zIsPermissionFirstTimeAsking) {
                this.savedReturnObject.put(NEVER_ASKED, true);
            }
            if (Build.VERSION.SDK_INT >= 23) {
                if (!zIsPermissionFirstTimeAsking && !getActivity().shouldShowRequestPermissionRationale(PERMISSION_NAME)) {
                    this.savedReturnObject.put(DENIED, true);
                } else if (z) {
                    requestPermissionForAlias(PERMISSION_ALIAS_CAMERA, pluginCall, "cameraPermsCallback");
                    return;
                }
            } else {
                this.savedReturnObject.put(GRANTED, true);
            }
        }
        pluginCall.resolve(this.savedReturnObject);
    }

    private void setPermissionFirstTimeAsking(String str, boolean z) {
        getActivity().getSharedPreferences(PREFS_PERMISSION_FIRST_TIME_ASKING, 0).edit().putBoolean(str, z).apply();
    }

    private boolean isPermissionFirstTimeAsking(String str) {
        return getActivity().getSharedPreferences(PREFS_PERMISSION_FIRST_TIME_ASKING, 0).getBoolean(str, true);
    }

    @PermissionCallback
    private void cameraPermsCallback(PluginCall pluginCall) {
        if (this.savedReturnObject == null) {
            return;
        }
        setPermissionFirstTimeAsking(PERMISSION_NAME, false);
        boolean z = getPermissionState(PERMISSION_ALIAS_CAMERA) == PermissionState.GRANTED;
        this.savedReturnObject.put(ASKED, true);
        if (!z && Build.VERSION.SDK_INT >= 23) {
            if (getActivity().shouldShowRequestPermissionRationale(PERMISSION_NAME)) {
                Log.d(TAG_PERMISSION, "Asked. Denied For Now");
            } else {
                Log.d(TAG_PERMISSION, "Asked. Denied");
                this.savedReturnObject.put(DENIED, true);
            }
        } else {
            Log.d(TAG_PERMISSION, "Asked. Granted");
            this.savedReturnObject.put(GRANTED, true);
        }
        pluginCall.resolve(this.savedReturnObject);
        this.savedReturnObject = null;
    }

    @PluginMethod
    public void checkPermission(PluginCall pluginCall) {
        Boolean bool = pluginCall.getBoolean("force", false);
        if (bool != null && bool.booleanValue()) {
            _checkPermission(pluginCall, true);
        } else {
            _checkPermission(pluginCall, false);
        }
    }

    @PluginMethod
    public void openAppSettings(PluginCall pluginCall) {
        Intent intent = new Intent("android.settings.APPLICATION_DETAILS_SETTINGS", Uri.fromParts("package", getAppId(), null));
        intent.addFlags(268435456);
        startActivityForResult(pluginCall, intent, "openSettingsResult");
    }

    @ActivityCallback
    private void openSettingsResult(PluginCall pluginCall, ActivityResult activityResult) {
        pluginCall.resolve();
    }

    private void setTorch(final boolean z) {
        if (z != this.isTorchOn) {
            this.isTorchOn = z;
            getActivity().runOnUiThread(new Runnable() { // from class: com.getcapacitor.community.barcodescanner.BarcodeScanner$$ExternalSyntheticLambda6
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$setTorch$6(z);
                }
            });
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$setTorch$6(boolean z) {
        BarcodeView barcodeView = this.mBarcodeView;
        if (barcodeView != null) {
            barcodeView.setTorch(z);
        }
    }

    @PluginMethod
    public void enableTorch(PluginCall pluginCall) {
        setTorch(true);
        pluginCall.resolve();
    }

    @PluginMethod
    public void disableTorch(PluginCall pluginCall) {
        setTorch(false);
        pluginCall.resolve();
    }

    @PluginMethod
    public void toggleTorch(PluginCall pluginCall) {
        setTorch(!this.isTorchOn);
        pluginCall.resolve();
    }

    @PluginMethod
    public void getTorchState(PluginCall pluginCall) {
        JSObject jSObject = new JSObject();
        jSObject.put("isEnabled", this.isTorchOn);
        pluginCall.resolve(jSObject);
    }
}
