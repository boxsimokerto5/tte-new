package com.getcapacitor.community.barcodescanner;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class id {
        public static int webview = 0x7f0901d2;

        private id() {
        }
    }

    public static final class layout {
        public static int bridge_layout_main = 0x7f0c001e;

        private layout() {
        }
    }

    private R() {
    }
}
