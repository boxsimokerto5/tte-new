package com.getcapacitor;

/* JADX INFO: loaded from: classes.dex */
public class ProcessedRoute {
    private boolean ignoreAssetPath;
    private boolean isAsset;
    private String path;

    public String getPath() {
        return this.path;
    }

    public boolean isAsset() {
        return this.isAsset;
    }

    public boolean isIgnoreAssetPath() {
        return this.ignoreAssetPath;
    }

    public void setAsset(boolean z) {
        this.isAsset = z;
    }

    public void setIgnoreAssetPath(boolean z) {
        this.ignoreAssetPath = z;
    }

    public void setPath(String str) {
        this.path = str;
    }
}
