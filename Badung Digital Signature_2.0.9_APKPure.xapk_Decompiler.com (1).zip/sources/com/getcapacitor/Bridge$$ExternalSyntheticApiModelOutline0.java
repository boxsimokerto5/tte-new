package com.getcapacitor;

import android.app.NotificationChannel;
import android.os.VibratorManager;
import android.security.keystore.KeyGenParameterSpec;
import java.nio.file.attribute.BasicFileAttributes;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class Bridge$$ExternalSyntheticApiModelOutline0 {
    public static /* bridge */ /* synthetic */ NotificationChannel m(Object obj) {
        return (NotificationChannel) obj;
    }

    public static /* synthetic */ NotificationChannel m(String str, CharSequence charSequence, int i) {
        return new NotificationChannel(str, charSequence, i);
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ VibratorManager m238m(Object obj) {
        return (VibratorManager) obj;
    }

    public static /* synthetic */ KeyGenParameterSpec.Builder m(String str, int i) {
        return new KeyGenParameterSpec.Builder(str, i);
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* bridge */ /* synthetic */ Class m240m() {
        return BasicFileAttributes.class;
    }

    /* JADX INFO: renamed from: m, reason: collision with other method in class */
    public static /* synthetic */ void m243m() {
    }
}
