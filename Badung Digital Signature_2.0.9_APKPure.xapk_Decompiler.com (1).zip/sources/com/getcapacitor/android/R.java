package com.getcapacitor.android;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class attr {
        public static int start_dir = 0x7f0403be;

        private attr() {
        }
    }

    public static final class color {
        public static int colorAccent = 0x7f060034;
        public static int colorPrimary = 0x7f060035;
        public static int colorPrimaryDark = 0x7f060036;

        private color() {
        }
    }

    public static final class id {
        public static int textView = 0x7f0901ac;
        public static int webview = 0x7f0901d2;

        private id() {
        }
    }

    public static final class layout {
        public static int bridge_layout_main = 0x7f0c001e;
        public static int fragment_bridge = 0x7f0c0033;
        public static int no_webview = 0x7f0c0069;

        private layout() {
        }
    }

    public static final class string {
        public static int no_webview_text = 0x7f1200d7;

        private string() {
        }
    }

    public static final class style {
        public static int AppTheme_NoActionBar = 0x7f13000d;

        private style() {
        }
    }

    public static final class styleable {
        public static int[] bridge_fragment = {com.badungkab.digital_signature.R.attr.start_dir};
        public static int bridge_fragment_start_dir;

        private styleable() {
        }
    }

    private R() {
    }
}
