package com.getcapacitor;

import java.util.Locale;

/* JADX INFO: loaded from: classes.dex */
public enum PermissionState {
    GRANTED("granted"),
    DENIED("denied"),
    PROMPT("prompt"),
    PROMPT_WITH_RATIONALE("prompt-with-rationale");

    private String state;

    @Override // java.lang.Enum
    public String toString() {
        return this.state;
    }

    PermissionState(String str) {
        this.state = str;
    }

    public static PermissionState byState(String str) {
        return valueOf(str.toUpperCase(Locale.ROOT).replace('-', '_'));
    }
}
