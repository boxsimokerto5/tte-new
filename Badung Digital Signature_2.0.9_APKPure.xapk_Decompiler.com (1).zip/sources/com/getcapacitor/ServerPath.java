package com.getcapacitor;

/* JADX INFO: loaded from: classes.dex */
public class ServerPath {
    private final String path;
    private final PathType type;

    public enum PathType {
        BASE_PATH,
        ASSET_PATH
    }

    public String getPath() {
        return this.path;
    }

    public PathType getType() {
        return this.type;
    }

    public ServerPath(PathType pathType, String str) {
        this.type = pathType;
        this.path = str;
    }
}
