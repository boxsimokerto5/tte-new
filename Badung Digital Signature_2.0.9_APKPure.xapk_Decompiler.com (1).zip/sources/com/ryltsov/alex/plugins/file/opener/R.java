package com.ryltsov.alex.plugins.file.opener;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class xml {
        public static int file_opener_paths = 0x7f150001;

        private xml() {
        }
    }

    private R() {
    }
}
