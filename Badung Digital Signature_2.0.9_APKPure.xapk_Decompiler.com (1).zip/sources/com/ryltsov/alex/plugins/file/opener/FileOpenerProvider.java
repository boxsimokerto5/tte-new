package com.ryltsov.alex.plugins.file.opener;

import androidx.core.content.FileProvider;

/* JADX INFO: loaded from: classes.dex */
public class FileOpenerProvider extends FileProvider {
}
