package com.google.android.material.shape;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/* JADX INFO: loaded from: classes.dex */
@Retention(RetentionPolicy.SOURCE)
public @interface CornerFamily {
    public static final int CUT = 1;
    public static final int ROUNDED = 0;
}
