package com.capacitorjs.plugins.localnotifications;

/* JADX INFO: compiled from: D8$$SyntheticClass */
/* JADX INFO: loaded from: classes.dex */
public final /* synthetic */ class LocalNotification$$ExternalSyntheticBackport0 {
    public static /* synthetic */ int m(boolean z) {
        return z ? 1231 : 1237;
    }
}
