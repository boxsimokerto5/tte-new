package com.capacitorjs.plugins.localnotifications;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class drawable {
        public static int ic_transparent = 0x7f080123;

        private drawable() {
        }
    }

    private R() {
    }
}
