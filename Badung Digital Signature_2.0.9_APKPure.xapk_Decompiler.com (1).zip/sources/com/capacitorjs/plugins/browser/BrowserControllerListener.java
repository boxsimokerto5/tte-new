package com.capacitorjs.plugins.browser;

/* JADX INFO: loaded from: classes.dex */
public interface BrowserControllerListener {
    void onControllerReady(BrowserControllerActivity browserControllerActivity);
}
