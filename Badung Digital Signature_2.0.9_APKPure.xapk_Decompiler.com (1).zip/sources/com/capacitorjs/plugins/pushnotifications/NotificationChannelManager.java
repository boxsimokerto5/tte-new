package com.capacitorjs.plugins.pushnotifications;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import com.getcapacitor.Bridge$$ExternalSyntheticApiModelOutline0;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Logger;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginConfig;
import com.getcapacitor.util.WebColor;
import java.util.Iterator;
import java.util.List;

/* JADX INFO: loaded from: classes.dex */
public class NotificationChannelManager {
    private static String CHANNEL_DESCRIPTION = "description";
    private static String CHANNEL_ID = "id";
    private static String CHANNEL_IMPORTANCE = "importance";
    private static String CHANNEL_LIGHT_COLOR = "lightColor";
    private static String CHANNEL_NAME = "name";
    private static String CHANNEL_SOUND = "sound";
    private static String CHANNEL_USE_LIGHTS = "lights";
    private static String CHANNEL_VIBRATE = "vibration";
    private static String CHANNEL_VISIBILITY = "visibility";
    private PluginConfig config;
    private Context context;
    private NotificationManager notificationManager;

    public NotificationChannelManager(Context context, NotificationManager notificationManager, PluginConfig pluginConfig) {
        this.context = context;
        this.notificationManager = notificationManager;
        this.config = pluginConfig;
    }

    public void createChannel(PluginCall pluginCall) {
        if (Build.VERSION.SDK_INT >= 26) {
            JSObject jSObject = new JSObject();
            if (pluginCall.getString(CHANNEL_ID) != null) {
                String str = CHANNEL_ID;
                jSObject.put(str, pluginCall.getString(str));
                if (pluginCall.getString(CHANNEL_NAME) != null) {
                    String str2 = CHANNEL_NAME;
                    jSObject.put(str2, pluginCall.getString(str2));
                    String str3 = CHANNEL_IMPORTANCE;
                    jSObject.put(str3, (Object) pluginCall.getInt(str3, 3));
                    String str4 = CHANNEL_DESCRIPTION;
                    jSObject.put(str4, pluginCall.getString(str4, ""));
                    String str5 = CHANNEL_VISIBILITY;
                    jSObject.put(str5, (Object) pluginCall.getInt(str5, 1));
                    String str6 = CHANNEL_SOUND;
                    jSObject.put(str6, pluginCall.getString(str6, null));
                    String str7 = CHANNEL_VIBRATE;
                    jSObject.put(str7, (Object) pluginCall.getBoolean(str7, false));
                    String str8 = CHANNEL_USE_LIGHTS;
                    jSObject.put(str8, (Object) pluginCall.getBoolean(str8, false));
                    String str9 = CHANNEL_LIGHT_COLOR;
                    jSObject.put(str9, pluginCall.getString(str9, null));
                    createChannel(jSObject);
                    pluginCall.resolve();
                    return;
                }
                pluginCall.reject("Channel missing name");
                return;
            }
            pluginCall.reject("Channel missing identifier");
            return;
        }
        pluginCall.unavailable();
    }

    public void createChannel(JSObject jSObject) {
        if (Build.VERSION.SDK_INT >= 26) {
            Bridge$$ExternalSyntheticApiModelOutline0.m243m();
            NotificationChannel notificationChannelM = Bridge$$ExternalSyntheticApiModelOutline0.m(jSObject.getString(CHANNEL_ID), jSObject.getString(CHANNEL_NAME), jSObject.getInteger(CHANNEL_IMPORTANCE).intValue());
            notificationChannelM.setDescription(jSObject.getString(CHANNEL_DESCRIPTION));
            notificationChannelM.setLockscreenVisibility(jSObject.getInteger(CHANNEL_VISIBILITY).intValue());
            notificationChannelM.enableVibration(jSObject.getBool(CHANNEL_VIBRATE).booleanValue());
            notificationChannelM.enableLights(jSObject.getBool(CHANNEL_USE_LIGHTS).booleanValue());
            String string = jSObject.getString(CHANNEL_LIGHT_COLOR);
            if (string != null) {
                try {
                    notificationChannelM.setLightColor(WebColor.parseColor(string));
                } catch (IllegalArgumentException unused) {
                    Logger.error(Logger.tags("NotificationChannel"), "Invalid color provided for light color.", null);
                }
            }
            String string2 = jSObject.getString(CHANNEL_SOUND, null);
            if (string2 != null && !string2.isEmpty()) {
                if (string2.contains(".")) {
                    string2 = string2.substring(0, string2.lastIndexOf(46));
                }
                notificationChannelM.setSound(Uri.parse("android.resource://" + this.context.getPackageName() + "/raw/" + string2), new AudioAttributes.Builder().setContentType(4).setUsage(5).build());
            }
            this.notificationManager.createNotificationChannel(notificationChannelM);
        }
    }

    public void deleteChannel(PluginCall pluginCall) {
        if (Build.VERSION.SDK_INT >= 26) {
            this.notificationManager.deleteNotificationChannel(pluginCall.getString("id"));
            pluginCall.resolve();
            return;
        }
        pluginCall.unavailable();
    }

    public void listChannels(PluginCall pluginCall) {
        if (Build.VERSION.SDK_INT >= 26) {
            List notificationChannels = this.notificationManager.getNotificationChannels();
            JSArray jSArray = new JSArray();
            Iterator it = notificationChannels.iterator();
            while (it.hasNext()) {
                NotificationChannel notificationChannelM = Bridge$$ExternalSyntheticApiModelOutline0.m(it.next());
                JSObject jSObject = new JSObject();
                jSObject.put(CHANNEL_ID, notificationChannelM.getId());
                jSObject.put(CHANNEL_NAME, (Object) notificationChannelM.getName());
                jSObject.put(CHANNEL_DESCRIPTION, notificationChannelM.getDescription());
                jSObject.put(CHANNEL_IMPORTANCE, notificationChannelM.getImportance());
                jSObject.put(CHANNEL_VISIBILITY, notificationChannelM.getLockscreenVisibility());
                jSObject.put(CHANNEL_SOUND, (Object) notificationChannelM.getSound());
                jSObject.put(CHANNEL_VIBRATE, notificationChannelM.shouldVibrate());
                jSObject.put(CHANNEL_USE_LIGHTS, notificationChannelM.shouldShowLights());
                jSObject.put(CHANNEL_LIGHT_COLOR, String.format("#%06X", Integer.valueOf(16777215 & notificationChannelM.getLightColor())));
                Logger.debug(Logger.tags("NotificationChannel"), "visibility " + notificationChannelM.getLockscreenVisibility());
                Logger.debug(Logger.tags("NotificationChannel"), "importance " + notificationChannelM.getImportance());
                jSArray.put(jSObject);
            }
            JSObject jSObject2 = new JSObject();
            jSObject2.put("channels", (Object) jSArray);
            pluginCall.resolve(jSObject2);
            return;
        }
        pluginCall.unavailable();
    }
}
