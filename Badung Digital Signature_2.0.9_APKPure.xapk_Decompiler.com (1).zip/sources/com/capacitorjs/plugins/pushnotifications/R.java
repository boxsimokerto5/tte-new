package com.capacitorjs.plugins.pushnotifications;

/* JADX INFO: loaded from: classes.dex */
public final class R {
    private R() {
    }
}
