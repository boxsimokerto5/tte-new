package com.capacitorjs.plugins.haptics;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
import com.capacitorjs.plugins.haptics.arguments.HapticsSelectionType;
import com.capacitorjs.plugins.haptics.arguments.HapticsVibrationType;
import com.getcapacitor.Bridge$$ExternalSyntheticApiModelOutline0;

/* JADX INFO: loaded from: classes.dex */
public class Haptics {
    private Context context;
    private boolean selectionStarted = false;
    private final Vibrator vibrator;

    public void selectionEnd() {
        this.selectionStarted = false;
    }

    public void selectionStart() {
        this.selectionStarted = true;
    }

    Haptics(Context context) {
        this.context = context;
        if (Build.VERSION.SDK_INT >= 31) {
            this.vibrator = Bridge$$ExternalSyntheticApiModelOutline0.m238m(context.getSystemService("vibrator_manager")).getDefaultVibrator();
        } else {
            this.vibrator = getDeprecatedVibrator(context);
        }
    }

    private Vibrator getDeprecatedVibrator(Context context) {
        return (Vibrator) context.getSystemService("vibrator");
    }

    public void vibrate(int i) {
        if (Build.VERSION.SDK_INT >= 26) {
            this.vibrator.vibrate(VibrationEffect.createOneShot(i, -1));
        } else {
            vibratePre26(i);
        }
    }

    private void vibratePre26(int i) {
        this.vibrator.vibrate(i);
    }

    private void vibratePre26(long[] jArr, int i) {
        this.vibrator.vibrate(jArr, i);
    }

    public void selectionChanged() {
        if (this.selectionStarted) {
            performHaptics(new HapticsSelectionType());
        }
    }

    public void performHaptics(HapticsVibrationType hapticsVibrationType) {
        if (Build.VERSION.SDK_INT >= 26) {
            this.vibrator.vibrate(VibrationEffect.createWaveform(hapticsVibrationType.getTimings(), hapticsVibrationType.getAmplitudes(), -1));
        } else {
            vibratePre26(hapticsVibrationType.getOldSDKPattern(), -1);
        }
    }
}
