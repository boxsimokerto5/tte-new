package com.capacitorjs.plugins.haptics;

/* JADX INFO: loaded from: classes.dex */
public final class R {
    private R() {
    }
}
