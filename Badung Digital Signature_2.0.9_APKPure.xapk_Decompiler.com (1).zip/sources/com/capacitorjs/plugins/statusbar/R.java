package com.capacitorjs.plugins.statusbar;

/* JADX INFO: loaded from: classes.dex */
public final class R {
    private R() {
    }
}
