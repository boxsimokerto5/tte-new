package com.capacitorjs.plugins.filesystem;

import android.content.Context;
import android.net.Uri;
import android.os.Environment;
import android.util.Base64;
import androidx.browser.trusted.sharing.ShareTarget;
import androidx.core.app.NotificationCompat;
import com.capacitorjs.plugins.filesystem.exceptions.CopyFailedException;
import com.capacitorjs.plugins.filesystem.exceptions.DirectoryExistsException;
import com.capacitorjs.plugins.filesystem.exceptions.DirectoryNotFoundException;
import com.getcapacitor.Bridge;
import com.getcapacitor.JSObject;
import com.getcapacitor.PluginCall;
import com.getcapacitor.plugin.util.CapacitorHttpUrlConnection;
import com.getcapacitor.plugin.util.HttpRequestHandler;
import com.google.android.gms.common.internal.ImagesContract;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStreamWriter;
import java.net.URISyntaxException;
import java.net.URL;
import java.nio.channels.FileChannel;
import java.nio.charset.Charset;
import java.util.Locale;
import org.json.JSONException;

/* JADX INFO: loaded from: classes.dex */
public class Filesystem {
    private Context context;

    Filesystem(Context context) {
        this.context = context;
    }

    public String readFile(String str, String str2, Charset charset) throws IOException {
        InputStream inputStream = getInputStream(str, str2);
        if (charset != null) {
            return readFileAsString(inputStream, charset.name());
        }
        return readFileAsBase64EncodedData(inputStream);
    }

    public void saveFile(File file, String str, Charset charset, Boolean bool) throws IOException {
        if (charset != null) {
            BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file, bool.booleanValue()), charset));
            bufferedWriter.write(str);
            bufferedWriter.close();
        } else {
            if (str.contains(",")) {
                str = str.split(",")[1];
            }
            FileOutputStream fileOutputStream = new FileOutputStream(file, bool.booleanValue());
            fileOutputStream.write(Base64.decode(str, 2));
            fileOutputStream.close();
        }
    }

    public boolean deleteFile(String str, String str2) throws FileNotFoundException {
        File fileObject = getFileObject(str, str2);
        if (!fileObject.exists()) {
            throw new FileNotFoundException("File does not exist");
        }
        return fileObject.delete();
    }

    public boolean mkdir(String str, String str2, Boolean bool) throws DirectoryExistsException {
        File fileObject = getFileObject(str, str2);
        if (fileObject.exists()) {
            throw new DirectoryExistsException("Directory exists");
        }
        if (bool.booleanValue()) {
            return fileObject.mkdirs();
        }
        return fileObject.mkdir();
    }

    public File[] readdir(String str, String str2) throws DirectoryNotFoundException {
        File fileObject = getFileObject(str, str2);
        if (fileObject != null && fileObject.exists()) {
            return fileObject.listFiles();
        }
        throw new DirectoryNotFoundException("Directory does not exist");
    }

    public File copy(String str, String str2, String str3, String str4, boolean z) throws CopyFailedException, IOException {
        if (str4 == null) {
            str4 = str2;
        }
        File fileObject = getFileObject(str, str2);
        File fileObject2 = getFileObject(str3, str4);
        if (fileObject == null) {
            throw new CopyFailedException("from file is null");
        }
        if (fileObject2 == null) {
            throw new CopyFailedException("to file is null");
        }
        if (fileObject2.equals(fileObject)) {
            return fileObject2;
        }
        if (!fileObject.exists()) {
            throw new CopyFailedException("The source object does not exist");
        }
        if (fileObject2.getParentFile().isFile()) {
            throw new CopyFailedException("The parent object of the destination is a file");
        }
        if (!fileObject2.getParentFile().exists()) {
            throw new CopyFailedException("The parent object of the destination does not exist");
        }
        if (fileObject2.isDirectory()) {
            throw new CopyFailedException("Cannot overwrite a directory");
        }
        fileObject2.delete();
        if (z) {
            if (!fileObject.renameTo(fileObject2)) {
                throw new CopyFailedException("Unable to rename, unknown reason");
            }
        } else {
            copyRecursively(fileObject, fileObject2);
        }
        return fileObject2;
    }

    public InputStream getInputStream(String str, String str2) throws IOException {
        if (str2 == null) {
            Uri uri = Uri.parse(str);
            if (uri.getScheme().equals("content")) {
                return this.context.getContentResolver().openInputStream(uri);
            }
            return new FileInputStream(new File(uri.getPath()));
        }
        File directory = getDirectory(str2);
        if (directory == null) {
            throw new IOException("Directory not found");
        }
        return new FileInputStream(new File(directory, str));
    }

    public String readFileAsString(InputStream inputStream, String str) throws IOException {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[1024];
        while (true) {
            int i = inputStream.read(bArr);
            if (i != -1) {
                byteArrayOutputStream.write(bArr, 0, i);
            } else {
                return byteArrayOutputStream.toString(str);
            }
        }
    }

    public String readFileAsBase64EncodedData(InputStream inputStream) throws IOException {
        FileInputStream fileInputStream = (FileInputStream) inputStream;
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
        byte[] bArr = new byte[1024];
        while (true) {
            int i = fileInputStream.read(bArr);
            if (i != -1) {
                byteArrayOutputStream.write(bArr, 0, i);
            } else {
                fileInputStream.close();
                return Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2);
            }
        }
    }

    public File getDirectory(String str) {
        Context context;
        context = this.context;
        str.hashCode();
        switch (str) {
            case "EXTERNAL":
                return context.getExternalFilesDir(null);
            case "DOCUMENTS":
                return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOCUMENTS);
            case "DATA":
            case "LIBRARY":
                return context.getFilesDir();
            case "CACHE":
                return context.getCacheDir();
            case "EXTERNAL_STORAGE":
                return Environment.getExternalStorageDirectory();
            default:
                return null;
        }
    }

    public File getFileObject(String str, String str2) {
        if (str2 == null) {
            Uri uri = Uri.parse(str);
            if (uri.getScheme() == null || uri.getScheme().equals("file")) {
                return new File(uri.getPath());
            }
        }
        File directory = getDirectory(str2);
        if (directory == null) {
            return null;
        }
        if (!directory.exists()) {
            directory.mkdir();
        }
        return new File(directory, str);
    }

    public Charset getEncoding(String str) {
        if (str == null) {
            return null;
        }
        str.hashCode();
        switch (str) {
        }
        return null;
    }

    public void deleteRecursively(File file) throws IOException {
        if (file.isFile()) {
            file.delete();
            return;
        }
        for (File file2 : file.listFiles()) {
            deleteRecursively(file2);
        }
        file.delete();
    }

    public void copyRecursively(File file, File file2) throws IOException {
        if (file.isDirectory()) {
            file2.mkdir();
            for (String str : file.list()) {
                copyRecursively(new File(file, str), new File(file2, str));
            }
            return;
        }
        if (!file2.getParentFile().exists()) {
            file2.getParentFile().mkdirs();
        }
        if (!file2.exists()) {
            file2.createNewFile();
        }
        FileChannel channel = new FileInputStream(file).getChannel();
        try {
            FileChannel channel2 = new FileOutputStream(file2).getChannel();
            try {
                channel2.transferFrom(channel, 0L, channel.size());
                if (channel2 != null) {
                    channel2.close();
                }
                if (channel != null) {
                    channel.close();
                }
            } finally {
            }
        } catch (Throwable th) {
            if (channel != null) {
                try {
                    channel.close();
                } catch (Throwable th2) {
                    th.addSuppressed(th2);
                }
            }
            throw th;
        }
    }

    public JSObject downloadFile(PluginCall pluginCall, Bridge bridge, HttpRequestHandler.ProgressEmitter progressEmitter) throws JSONException, URISyntaxException, IOException {
        int i;
        String string = pluginCall.getString(ImagesContract.URL, "");
        JSObject object = pluginCall.getObject("headers", new JSObject());
        JSObject object2 = pluginCall.getObject("params", new JSObject());
        Integer num = pluginCall.getInt("connectTimeout");
        Integer num2 = pluginCall.getInt("readTimeout");
        Boolean bool = pluginCall.getBoolean("disableRedirects");
        Boolean bool2 = pluginCall.getBoolean("shouldEncodeUrlParams", true);
        Boolean bool3 = pluginCall.getBoolean(NotificationCompat.CATEGORY_PROGRESS, false);
        String upperCase = pluginCall.getString("method", ShareTarget.METHOD_GET).toUpperCase(Locale.ROOT);
        String string2 = pluginCall.getString("path");
        String string3 = pluginCall.getString("directory", Environment.DIRECTORY_DOWNLOADS);
        URL url = new URL(string);
        File fileObject = getFileObject(string2, string3);
        CapacitorHttpUrlConnection capacitorHttpUrlConnectionBuild = new HttpRequestHandler.HttpURLConnectionBuilder().setUrl(url).setMethod(upperCase).setHeaders(object).setUrlParams(object2, bool2.booleanValue()).setConnectTimeout(num).setReadTimeout(num2).setDisableRedirects(bool).openConnection().build();
        capacitorHttpUrlConnectionBuild.setSSLSocketFactory(bridge);
        InputStream inputStream = capacitorHttpUrlConnectionBuild.getInputStream();
        FileOutputStream fileOutputStream = new FileOutputStream(fileObject, false);
        String headerField = capacitorHttpUrlConnectionBuild.getHeaderField("content-length");
        if (headerField != null) {
            try {
                i = Integer.parseInt(headerField);
            } catch (NumberFormatException unused) {
                i = 0;
            }
        } else {
            i = 0;
        }
        byte[] bArr = new byte[1024];
        long jCurrentTimeMillis = System.currentTimeMillis();
        int i2 = 0;
        while (true) {
            int i3 = inputStream.read(bArr);
            if (i3 <= 0) {
                break;
            }
            fileOutputStream.write(bArr, 0, i3);
            i2 += i3;
            if (bool3.booleanValue() && progressEmitter != null) {
                long jCurrentTimeMillis2 = System.currentTimeMillis();
                if (jCurrentTimeMillis2 - jCurrentTimeMillis > 100) {
                    progressEmitter.emit(Integer.valueOf(i2), Integer.valueOf(i));
                    jCurrentTimeMillis = jCurrentTimeMillis2;
                }
            }
        }
        if (bool3.booleanValue() && progressEmitter != null) {
            progressEmitter.emit(Integer.valueOf(i2), Integer.valueOf(i));
        }
        inputStream.close();
        fileOutputStream.close();
        return new JSObject(fileObject) { // from class: com.capacitorjs.plugins.filesystem.Filesystem.1
            final /* synthetic */ File val$file;

            {
                this.val$file = fileObject;
                put("path", fileObject.getAbsolutePath());
            }
        };
    }
}
