package com.capacitorjs.plugins.filesystem;

/* JADX INFO: loaded from: classes.dex */
public final class R {
    private R() {
    }
}
