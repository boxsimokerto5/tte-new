package com.capacitorjs.plugins.filesystem.exceptions;

/* JADX INFO: loaded from: classes.dex */
public class DirectoryExistsException extends Exception {
    public DirectoryExistsException(String str) {
        super(str);
    }

    public DirectoryExistsException(Throwable th) {
        super(th);
    }

    public DirectoryExistsException(String str, Throwable th) {
        super(str, th);
    }
}
