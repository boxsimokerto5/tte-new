package com.capacitorjs.plugins.filesystem.exceptions;

/* JADX INFO: loaded from: classes.dex */
public class CopyFailedException extends Exception {
    public CopyFailedException(String str) {
        super(str);
    }

    public CopyFailedException(Throwable th) {
        super(th);
    }

    public CopyFailedException(String str, Throwable th) {
        super(str, th);
    }
}
