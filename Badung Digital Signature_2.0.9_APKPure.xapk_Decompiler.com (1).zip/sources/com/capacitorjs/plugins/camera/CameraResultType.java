package com.capacitorjs.plugins.camera;

/* JADX INFO: loaded from: classes.dex */
public enum CameraResultType {
    BASE64("base64"),
    URI("uri"),
    DATAURL("dataUrl");

    private String type;

    public String getType() {
        return this.type;
    }

    CameraResultType(String str) {
        this.type = str;
    }
}
