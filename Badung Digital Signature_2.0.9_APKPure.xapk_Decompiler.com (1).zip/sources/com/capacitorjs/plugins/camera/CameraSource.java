package com.capacitorjs.plugins.camera;

/* JADX INFO: loaded from: classes.dex */
public enum CameraSource {
    PROMPT("PROMPT"),
    CAMERA("CAMERA"),
    PHOTOS("PHOTOS");

    private String source;

    public String getSource() {
        return this.source;
    }

    CameraSource(String str) {
        this.source = str;
    }
}
