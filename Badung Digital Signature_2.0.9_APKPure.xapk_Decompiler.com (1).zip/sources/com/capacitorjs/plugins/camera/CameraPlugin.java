package com.capacitorjs.plugins.camera;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Base64;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.ActivityResultRegistryOwner;
import androidx.activity.result.PickVisualMediaRequest;
import androidx.activity.result.contract.ActivityResultContract;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.FileProvider;
import com.capacitorjs.plugins.camera.CameraBottomSheetDialogFragment;
import com.getcapacitor.FileUtils;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Logger;
import com.getcapacitor.PermissionState;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;
import com.getcapacitor.annotation.Permission;
import com.getcapacitor.annotation.PermissionCallback;
import com.google.firebase.messaging.Constants;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONException;

/* JADX INFO: loaded from: classes.dex */
@CapacitorPlugin(name = "Camera", permissions = {@Permission(alias = "camera", strings = {"android.permission.CAMERA"}), @Permission(alias = CameraPlugin.PHOTOS, strings = {}), @Permission(alias = CameraPlugin.SAVE_GALLERY, strings = {"android.permission.READ_EXTERNAL_STORAGE", "android.permission.WRITE_EXTERNAL_STORAGE"}), @Permission(alias = CameraPlugin.READ_EXTERNAL_STORAGE, strings = {"android.permission.READ_EXTERNAL_STORAGE"})})
public class CameraPlugin extends Plugin {
    static final String CAMERA = "camera";
    private static final String IMAGE_EDIT_ERROR = "Unable to edit image";
    private static final String IMAGE_FILE_SAVE_ERROR = "Unable to create photo on disk";
    private static final String IMAGE_GALLERY_SAVE_ERROR = "Unable to save the image in the gallery";
    private static final String IMAGE_PROCESS_NO_FILE_ERROR = "Unable to process image, file not found on disk";
    private static final String INVALID_RESULT_TYPE_ERROR = "Invalid resultType option";
    private static final String NO_CAMERA_ACTIVITY_ERROR = "Unable to resolve camera activity";
    private static final String NO_CAMERA_ERROR = "Device doesn't have a camera available";
    private static final String NO_PHOTO_ACTIVITY_ERROR = "Unable to resolve photo activity";
    private static final String PERMISSION_DENIED_ERROR_CAMERA = "User denied access to camera";
    static final String PHOTOS = "photos";
    static final String READ_EXTERNAL_STORAGE = "readExternalStorage";
    static final String SAVE_GALLERY = "saveGallery";
    private static final String UNABLE_TO_PROCESS_IMAGE = "Unable to process image";
    private static final String USER_CANCELLED = "User cancelled photos app";
    private String imageEditedFileSavePath;
    private String imageFileSavePath;
    private Uri imageFileUri;
    private Uri imagePickedContentUri;
    private boolean isEdited = false;
    private boolean isFirstRequest = true;
    private boolean isSaved = false;
    private ActivityResultLauncher<PickVisualMediaRequest> pickMultipleMedia = null;
    private ActivityResultLauncher<PickVisualMediaRequest> pickMedia = null;
    private final AtomicInteger mNextLocalRequestCode = new AtomicInteger();
    private CameraSettings settings = new CameraSettings();

    @Override // com.getcapacitor.Plugin
    public void load() {
        super.load();
    }

    @PluginMethod
    public void getPhoto(PluginCall pluginCall) {
        this.isEdited = false;
        this.settings = getSettings(pluginCall);
        doShow(pluginCall);
    }

    @PluginMethod
    public void pickImages(PluginCall pluginCall) {
        this.settings = getSettings(pluginCall);
        openPhotos(pluginCall, true);
    }

    @PluginMethod
    public void pickLimitedLibraryPhotos(PluginCall pluginCall) {
        pluginCall.unimplemented("not supported on android");
    }

    @PluginMethod
    public void getLimitedLibraryPhotos(PluginCall pluginCall) {
        pluginCall.unimplemented("not supported on android");
    }

    /* JADX INFO: renamed from: com.capacitorjs.plugins.camera.CameraPlugin$1, reason: invalid class name */
    static /* synthetic */ class AnonymousClass1 {
        static final /* synthetic */ int[] $SwitchMap$com$capacitorjs$plugins$camera$CameraSource;

        static {
            int[] iArr = new int[CameraSource.values().length];
            $SwitchMap$com$capacitorjs$plugins$camera$CameraSource = iArr;
            try {
                iArr[CameraSource.CAMERA.ordinal()] = 1;
            } catch (NoSuchFieldError unused) {
            }
            try {
                $SwitchMap$com$capacitorjs$plugins$camera$CameraSource[CameraSource.PHOTOS.ordinal()] = 2;
            } catch (NoSuchFieldError unused2) {
            }
        }
    }

    private void doShow(PluginCall pluginCall) {
        int i = AnonymousClass1.$SwitchMap$com$capacitorjs$plugins$camera$CameraSource[this.settings.getSource().ordinal()];
        if (i == 1) {
            showCamera(pluginCall);
        } else if (i == 2) {
            showPhotos(pluginCall);
        } else {
            showPrompt(pluginCall);
        }
    }

    private void showPrompt(final PluginCall pluginCall) {
        ArrayList arrayList = new ArrayList();
        arrayList.add(pluginCall.getString("promptLabelPhoto", "From Photos"));
        arrayList.add(pluginCall.getString("promptLabelPicture", "Take Picture"));
        CameraBottomSheetDialogFragment cameraBottomSheetDialogFragment = new CameraBottomSheetDialogFragment();
        cameraBottomSheetDialogFragment.setTitle(pluginCall.getString("promptLabelHeader", "Photo"));
        cameraBottomSheetDialogFragment.setOptions(arrayList, new CameraBottomSheetDialogFragment.BottomSheetOnSelectedListener() { // from class: com.capacitorjs.plugins.camera.CameraPlugin$$ExternalSyntheticLambda5
            @Override // com.capacitorjs.plugins.camera.CameraBottomSheetDialogFragment.BottomSheetOnSelectedListener
            public final void onSelected(int i) {
                this.f$0.lambda$showPrompt$0(pluginCall, i);
            }
        }, new CameraBottomSheetDialogFragment.BottomSheetOnCanceledListener() { // from class: com.capacitorjs.plugins.camera.CameraPlugin$$ExternalSyntheticLambda6
            @Override // com.capacitorjs.plugins.camera.CameraBottomSheetDialogFragment.BottomSheetOnCanceledListener
            public final void onCanceled() {
                pluginCall.reject(CameraPlugin.USER_CANCELLED);
            }
        });
        cameraBottomSheetDialogFragment.show(getActivity().getSupportFragmentManager(), "capacitorModalsActionSheet");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$showPrompt$0(PluginCall pluginCall, int i) {
        if (i == 0) {
            this.settings.setSource(CameraSource.PHOTOS);
            openPhotos(pluginCall);
        } else if (i == 1) {
            this.settings.setSource(CameraSource.CAMERA);
            openCamera(pluginCall);
        }
    }

    private void showCamera(PluginCall pluginCall) {
        if (!getContext().getPackageManager().hasSystemFeature("android.hardware.camera.any")) {
            pluginCall.reject(NO_CAMERA_ERROR);
        } else {
            openCamera(pluginCall);
        }
    }

    private void showPhotos(PluginCall pluginCall) {
        openPhotos(pluginCall);
    }

    private boolean checkCameraPermissions(PluginCall pluginCall) {
        String[] strArr;
        boolean zIsPermissionDeclared = isPermissionDeclared("camera");
        boolean z = !zIsPermissionDeclared || getPermissionState("camera") == PermissionState.GRANTED;
        boolean z2 = getPermissionState(SAVE_GALLERY) == PermissionState.GRANTED;
        if (!this.settings.isSaveToGallery() || ((z && z2) || !this.isFirstRequest)) {
            if (z) {
                return true;
            }
            requestPermissionForAlias("camera", pluginCall, "cameraPermissionsCallback");
            return false;
        }
        this.isFirstRequest = false;
        if (zIsPermissionDeclared) {
            strArr = new String[]{"camera", SAVE_GALLERY};
        } else {
            strArr = new String[]{SAVE_GALLERY};
        }
        requestPermissionForAliases(strArr, pluginCall, "cameraPermissionsCallback");
        return false;
    }

    @PermissionCallback
    private void cameraPermissionsCallback(PluginCall pluginCall) {
        if (pluginCall.getMethodName().equals("pickImages")) {
            openPhotos(pluginCall, true);
            return;
        }
        if (this.settings.getSource() == CameraSource.CAMERA && getPermissionState("camera") != PermissionState.GRANTED) {
            Logger.debug(getLogTag(), "User denied camera permission: " + getPermissionState("camera").toString());
            pluginCall.reject(PERMISSION_DENIED_ERROR_CAMERA);
            return;
        }
        doShow(pluginCall);
    }

    @Override // com.getcapacitor.Plugin
    protected void requestPermissionForAliases(String[] strArr, PluginCall pluginCall, String str) {
        int i = 0;
        if (Build.VERSION.SDK_INT >= 33) {
            while (i < strArr.length) {
                if (strArr[i].equals(SAVE_GALLERY)) {
                    strArr[i] = PHOTOS;
                }
                i++;
            }
        } else if (Build.VERSION.SDK_INT >= 30) {
            while (i < strArr.length) {
                if (strArr[i].equals(SAVE_GALLERY)) {
                    strArr[i] = READ_EXTERNAL_STORAGE;
                }
                i++;
            }
        }
        super.requestPermissionForAliases(strArr, pluginCall, str);
    }

    private CameraSettings getSettings(PluginCall pluginCall) {
        CameraSettings cameraSettings = new CameraSettings();
        cameraSettings.setResultType(getResultType(pluginCall.getString("resultType")));
        cameraSettings.setSaveToGallery(pluginCall.getBoolean("saveToGallery", false).booleanValue());
        cameraSettings.setAllowEditing(pluginCall.getBoolean("allowEditing", false).booleanValue());
        cameraSettings.setQuality(pluginCall.getInt("quality", 90).intValue());
        cameraSettings.setWidth(pluginCall.getInt("width", 0).intValue());
        cameraSettings.setHeight(pluginCall.getInt("height", 0).intValue());
        cameraSettings.setShouldResize(cameraSettings.getWidth() > 0 || cameraSettings.getHeight() > 0);
        cameraSettings.setShouldCorrectOrientation(pluginCall.getBoolean("correctOrientation", true).booleanValue());
        try {
            cameraSettings.setSource(CameraSource.valueOf(pluginCall.getString(Constants.ScionAnalytics.PARAM_SOURCE, CameraSource.PROMPT.getSource())));
        } catch (IllegalArgumentException unused) {
            cameraSettings.setSource(CameraSource.PROMPT);
        }
        return cameraSettings;
    }

    private CameraResultType getResultType(String str) {
        if (str == null) {
            return null;
        }
        try {
            return CameraResultType.valueOf(str.toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException unused) {
            Logger.debug(getLogTag(), "Invalid result type \"" + str + "\", defaulting to base64");
            return CameraResultType.BASE64;
        }
    }

    public void openCamera(PluginCall pluginCall) {
        if (checkCameraPermissions(pluginCall)) {
            Intent intent = new Intent("android.media.action.IMAGE_CAPTURE");
            if (intent.resolveActivity(getContext().getPackageManager()) != null) {
                try {
                    String appId = getAppId();
                    File fileCreateImageFile = CameraUtils.createImageFile(getActivity());
                    this.imageFileSavePath = fileCreateImageFile.getAbsolutePath();
                    Uri uriForFile = FileProvider.getUriForFile(getActivity(), appId + ".fileprovider", fileCreateImageFile);
                    this.imageFileUri = uriForFile;
                    intent.putExtra("output", uriForFile);
                    startActivityForResult(pluginCall, intent, "processCameraImage");
                    return;
                } catch (Exception e) {
                    pluginCall.reject(IMAGE_FILE_SAVE_ERROR, e);
                    return;
                }
            }
            pluginCall.reject(NO_CAMERA_ACTIVITY_ERROR);
        }
    }

    public void openPhotos(PluginCall pluginCall) {
        openPhotos(pluginCall, false);
    }

    private <I, O> ActivityResultLauncher<I> registerActivityResultLauncher(ActivityResultContract<I, O> activityResultContract, ActivityResultCallback<O> activityResultCallback) {
        String str = "cap_activity_rq#" + this.mNextLocalRequestCode.getAndIncrement();
        if (this.bridge.getFragment() != null) {
            Object host = this.bridge.getFragment().getHost();
            if (host instanceof ActivityResultRegistryOwner) {
                return ((ActivityResultRegistryOwner) host).getActivityResultRegistry().register(str, activityResultContract, activityResultCallback);
            }
            return this.bridge.getFragment().requireActivity().getActivityResultRegistry().register(str, activityResultContract, activityResultCallback);
        }
        return this.bridge.getActivity().getActivityResultRegistry().register(str, activityResultContract, activityResultCallback);
    }

    private ActivityResultContract<PickVisualMediaRequest, List<Uri>> getContractForCall(PluginCall pluginCall) {
        int iIntValue = pluginCall.getInt("limit", 0).intValue();
        if (iIntValue > 1) {
            return new ActivityResultContracts.PickMultipleVisualMedia(iIntValue);
        }
        return new ActivityResultContracts.PickMultipleVisualMedia();
    }

    private void openPhotos(final PluginCall pluginCall, boolean z) {
        try {
            if (z) {
                ActivityResultLauncher<PickVisualMediaRequest> activityResultLauncherRegisterActivityResultLauncher = registerActivityResultLauncher(getContractForCall(pluginCall), new ActivityResultCallback() { // from class: com.capacitorjs.plugins.camera.CameraPlugin$$ExternalSyntheticLambda3
                    @Override // androidx.activity.result.ActivityResultCallback
                    public final void onActivityResult(Object obj) {
                        this.f$0.lambda$openPhotos$3(pluginCall, (List) obj);
                    }
                });
                this.pickMultipleMedia = activityResultLauncherRegisterActivityResultLauncher;
                activityResultLauncherRegisterActivityResultLauncher.launch(new PickVisualMediaRequest.Builder().setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE).build());
            } else {
                ActivityResultLauncher<PickVisualMediaRequest> activityResultLauncherRegisterActivityResultLauncher2 = registerActivityResultLauncher(new ActivityResultContracts.PickVisualMedia(), new ActivityResultCallback() { // from class: com.capacitorjs.plugins.camera.CameraPlugin$$ExternalSyntheticLambda4
                    @Override // androidx.activity.result.ActivityResultCallback
                    public final void onActivityResult(Object obj) {
                        this.f$0.lambda$openPhotos$4(pluginCall, (Uri) obj);
                    }
                });
                this.pickMedia = activityResultLauncherRegisterActivityResultLauncher2;
                activityResultLauncherRegisterActivityResultLauncher2.launch(new PickVisualMediaRequest.Builder().setMediaType(ActivityResultContracts.PickVisualMedia.ImageOnly.INSTANCE).build());
            }
        } catch (ActivityNotFoundException unused) {
            pluginCall.reject(NO_PHOTO_ACTIVITY_ERROR);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$openPhotos$3(final PluginCall pluginCall, final List list) {
        if (!list.isEmpty()) {
            Executors.newSingleThreadExecutor().execute(new Runnable() { // from class: com.capacitorjs.plugins.camera.CameraPlugin$$ExternalSyntheticLambda2
                @Override // java.lang.Runnable
                public final void run() {
                    this.f$0.lambda$openPhotos$2(list, pluginCall);
                }
            });
        } else {
            pluginCall.reject(USER_CANCELLED);
        }
        this.pickMultipleMedia.unregister();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$openPhotos$2(List list, PluginCall pluginCall) {
        JSObject jSObject = new JSObject();
        JSArray jSArray = new JSArray();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            try {
                JSObject jSObjectProcessPickedImages = processPickedImages((Uri) it.next());
                if (jSObjectProcessPickedImages.getString(Constants.IPC_BUNDLE_KEY_SEND_ERROR) != null && !jSObjectProcessPickedImages.getString(Constants.IPC_BUNDLE_KEY_SEND_ERROR).isEmpty()) {
                    pluginCall.reject(jSObjectProcessPickedImages.getString(Constants.IPC_BUNDLE_KEY_SEND_ERROR));
                    return;
                }
                jSArray.put(jSObjectProcessPickedImages);
            } catch (SecurityException unused) {
                pluginCall.reject("SecurityException");
            }
        }
        jSObject.put(PHOTOS, (Object) jSArray);
        pluginCall.resolve(jSObject);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public /* synthetic */ void lambda$openPhotos$4(PluginCall pluginCall, Uri uri) {
        if (uri != null) {
            this.imagePickedContentUri = uri;
            processPickedImage(uri, pluginCall);
        } else {
            pluginCall.reject(USER_CANCELLED);
        }
        this.pickMedia.unregister();
    }

    @ActivityCallback
    public void processCameraImage(PluginCall pluginCall, ActivityResult activityResult) throws Throwable {
        this.settings = getSettings(pluginCall);
        if (this.imageFileSavePath == null) {
            pluginCall.reject(IMAGE_PROCESS_NO_FILE_ERROR);
            return;
        }
        File file = new File(this.imageFileSavePath);
        BitmapFactory.Options options = new BitmapFactory.Options();
        Uri uriFromFile = Uri.fromFile(file);
        Bitmap bitmapDecodeFile = BitmapFactory.decodeFile(this.imageFileSavePath, options);
        if (bitmapDecodeFile == null) {
            pluginCall.reject(USER_CANCELLED);
        } else {
            returnResult(pluginCall, bitmapDecodeFile, uriFromFile);
        }
    }

    public void processPickedImage(PluginCall pluginCall, ActivityResult activityResult) {
        this.settings = getSettings(pluginCall);
        Intent data = activityResult.getData();
        if (data == null) {
            pluginCall.reject(USER_CANCELLED);
            return;
        }
        Uri data2 = data.getData();
        this.imagePickedContentUri = data2;
        processPickedImage(data2, pluginCall);
    }

    private ArrayList<Parcelable> getLegacyParcelableArrayList(Bundle bundle, String str) {
        return bundle.getParcelableArrayList(str);
    }

    private void processPickedImage(Uri uri, PluginCall pluginCall) {
        InputStream inputStreamOpenInputStream;
        Bitmap bitmapDecodeStream;
        InputStream inputStream = null;
        try {
            try {
                try {
                    try {
                        inputStreamOpenInputStream = getContext().getContentResolver().openInputStream(uri);
                        bitmapDecodeStream = BitmapFactory.decodeStream(inputStreamOpenInputStream);
                    } catch (FileNotFoundException e) {
                        pluginCall.reject("No such image found", e);
                        if (0 == 0) {
                            return;
                        } else {
                            inputStream.close();
                        }
                    }
                } catch (OutOfMemoryError unused) {
                    pluginCall.reject("Out of memory");
                    if (0 == 0) {
                        return;
                    } else {
                        inputStream.close();
                    }
                }
                if (bitmapDecodeStream != null) {
                    returnResult(pluginCall, bitmapDecodeStream, uri);
                    if (inputStreamOpenInputStream != null) {
                        inputStreamOpenInputStream.close();
                        return;
                    }
                    return;
                }
                pluginCall.reject("Unable to process bitmap");
                if (inputStreamOpenInputStream != null) {
                    try {
                        inputStreamOpenInputStream.close();
                    } catch (IOException e2) {
                        Logger.error(getLogTag(), UNABLE_TO_PROCESS_IMAGE, e2);
                    }
                }
            } catch (Throwable th) {
                if (0 != 0) {
                    try {
                        inputStream.close();
                    } catch (IOException e3) {
                        Logger.error(getLogTag(), UNABLE_TO_PROCESS_IMAGE, e3);
                    }
                }
                throw th;
            }
        } catch (IOException e4) {
            Logger.error(getLogTag(), UNABLE_TO_PROCESS_IMAGE, e4);
        }
    }

    private JSObject processPickedImages(Uri uri) {
        JSObject jSObject = new JSObject();
        InputStream inputStream = null;
        try {
            try {
                try {
                    try {
                        InputStream inputStreamOpenInputStream = getContext().getContentResolver().openInputStream(uri);
                        Bitmap bitmapDecodeStream = BitmapFactory.decodeStream(inputStreamOpenInputStream);
                        if (bitmapDecodeStream == null) {
                            jSObject.put(Constants.IPC_BUNDLE_KEY_SEND_ERROR, "Unable to process bitmap");
                            if (inputStreamOpenInputStream != null) {
                                try {
                                    inputStreamOpenInputStream.close();
                                } catch (IOException e) {
                                    Logger.error(getLogTag(), UNABLE_TO_PROCESS_IMAGE, e);
                                }
                            }
                            return jSObject;
                        }
                        ExifWrapper exifData = ImageUtils.getExifData(getContext(), bitmapDecodeStream, uri);
                        try {
                            Bitmap bitmapPrepareBitmap = prepareBitmap(bitmapDecodeStream, uri, exifData);
                            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream();
                            bitmapPrepareBitmap.compress(Bitmap.CompressFormat.JPEG, this.settings.getQuality(), byteArrayOutputStream);
                            Uri tempImage = getTempImage(uri, byteArrayOutputStream);
                            exifData.copyExif(tempImage.getPath());
                            if (tempImage != null) {
                                jSObject.put("format", "jpeg");
                                jSObject.put("exif", (Object) exifData.toJson());
                                jSObject.put("path", tempImage.toString());
                                jSObject.put("webPath", FileUtils.getPortablePath(getContext(), this.bridge.getLocalUrl(), tempImage));
                            } else {
                                jSObject.put(Constants.IPC_BUNDLE_KEY_SEND_ERROR, UNABLE_TO_PROCESS_IMAGE);
                            }
                            if (inputStreamOpenInputStream != null) {
                                try {
                                    inputStreamOpenInputStream.close();
                                } catch (IOException e2) {
                                    Logger.error(getLogTag(), UNABLE_TO_PROCESS_IMAGE, e2);
                                }
                            }
                            return jSObject;
                        } catch (IOException unused) {
                            jSObject.put(Constants.IPC_BUNDLE_KEY_SEND_ERROR, UNABLE_TO_PROCESS_IMAGE);
                            if (inputStreamOpenInputStream != null) {
                                try {
                                    inputStreamOpenInputStream.close();
                                } catch (IOException e3) {
                                    Logger.error(getLogTag(), UNABLE_TO_PROCESS_IMAGE, e3);
                                }
                            }
                            return jSObject;
                        }
                    } catch (IOException e4) {
                        Logger.error(getLogTag(), UNABLE_TO_PROCESS_IMAGE, e4);
                        return jSObject;
                    }
                } catch (FileNotFoundException e5) {
                    jSObject.put(Constants.IPC_BUNDLE_KEY_SEND_ERROR, "No such image found");
                    Logger.error(getLogTag(), "No such image found", e5);
                    if (0 != 0) {
                        inputStream.close();
                    }
                    return jSObject;
                }
            } catch (OutOfMemoryError unused2) {
                jSObject.put(Constants.IPC_BUNDLE_KEY_SEND_ERROR, "Out of memory");
                if (0 != 0) {
                    inputStream.close();
                }
                return jSObject;
            }
        } catch (Throwable th) {
            if (0 != 0) {
                try {
                    inputStream.close();
                } catch (IOException e6) {
                    Logger.error(getLogTag(), UNABLE_TO_PROCESS_IMAGE, e6);
                }
            }
            throw th;
        }
    }

    @ActivityCallback
    private void processEditedImage(PluginCall pluginCall, ActivityResult activityResult) throws Throwable {
        this.isEdited = true;
        this.settings = getSettings(pluginCall);
        if (activityResult.getResultCode() != 0) {
            processPickedImage(pluginCall, activityResult);
            return;
        }
        Uri uri = this.imagePickedContentUri;
        if (uri != null) {
            processPickedImage(uri, pluginCall);
        } else {
            processCameraImage(pluginCall, activityResult);
        }
    }

    private Uri saveImage(Uri uri, InputStream inputStream) throws IOException {
        File file;
        if (uri.getScheme().equals("content")) {
            file = getTempFile(uri);
        } else {
            file = new File(uri.getPath());
        }
        try {
            writePhoto(file, inputStream);
        } catch (FileNotFoundException unused) {
            file = getTempFile(uri);
            writePhoto(file, inputStream);
        }
        return Uri.fromFile(file);
    }

    private void writePhoto(File file, InputStream inputStream) throws IOException {
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        byte[] bArr = new byte[1024];
        while (true) {
            int i = inputStream.read(bArr);
            if (i != -1) {
                fileOutputStream.write(bArr, 0, i);
            } else {
                fileOutputStream.close();
                return;
            }
        }
    }

    private File getTempFile(Uri uri) {
        String lastPathSegment = Uri.parse(Uri.decode(uri.toString())).getLastPathSegment();
        if (!lastPathSegment.contains(".jpg") && !lastPathSegment.contains(".jpeg")) {
            lastPathSegment = lastPathSegment + "." + new Date().getTime() + ".jpeg";
        }
        return new File(getContext().getCacheDir(), lastPathSegment);
    }

    /* JADX WARN: Removed duplicated region for block: B:22:0x005a A[Catch: IOException -> 0x00cc, FileNotFoundException -> 0x00d7, TryCatch #3 {FileNotFoundException -> 0x00d7, IOException -> 0x00cc, blocks: (B:19:0x004d, B:20:0x004f, B:22:0x005a, B:24:0x0086, B:26:0x008c, B:28:0x00a2, B:29:0x00a5, B:30:0x00ac, B:31:0x00ad, B:32:0x00b4, B:33:0x00b5, B:35:0x00c9), top: B:60:0x004d }] */
    /* JADX WARN: Removed duplicated region for block: B:33:0x00b5 A[Catch: IOException -> 0x00cc, FileNotFoundException -> 0x00d7, TryCatch #3 {FileNotFoundException -> 0x00d7, IOException -> 0x00cc, blocks: (B:19:0x004d, B:20:0x004f, B:22:0x005a, B:24:0x0086, B:26:0x008c, B:28:0x00a2, B:29:0x00a5, B:30:0x00ac, B:31:0x00ad, B:32:0x00b4, B:33:0x00b5, B:35:0x00c9), top: B:60:0x004d }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    private void returnResult(com.getcapacitor.PluginCall r9, android.graphics.Bitmap r10, android.net.Uri r11) throws java.lang.Throwable {
        /*
            Method dump skipped, instruction units count: 304
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: com.capacitorjs.plugins.camera.CameraPlugin.returnResult(com.getcapacitor.PluginCall, android.graphics.Bitmap, android.net.Uri):void");
    }

    private void deleteImageFile() {
        if (this.imageFileSavePath == null || this.settings.isSaveToGallery()) {
            return;
        }
        File file = new File(this.imageFileSavePath);
        if (file.exists()) {
            file.delete();
        }
    }

    private void returnFileURI(PluginCall pluginCall, ExifWrapper exifWrapper, Bitmap bitmap, Uri uri, ByteArrayOutputStream byteArrayOutputStream) throws Throwable {
        Uri tempImage = getTempImage(uri, byteArrayOutputStream);
        exifWrapper.copyExif(tempImage.getPath());
        if (tempImage != null) {
            JSObject jSObject = new JSObject();
            jSObject.put("format", "jpeg");
            jSObject.put("exif", (Object) exifWrapper.toJson());
            jSObject.put("path", tempImage.toString());
            jSObject.put("webPath", FileUtils.getPortablePath(getContext(), this.bridge.getLocalUrl(), tempImage));
            jSObject.put("saved", this.isSaved);
            pluginCall.resolve(jSObject);
            return;
        }
        pluginCall.reject(UNABLE_TO_PROCESS_IMAGE);
    }

    private Uri getTempImage(Uri uri, ByteArrayOutputStream byteArrayOutputStream) throws Throwable {
        ByteArrayInputStream byteArrayInputStream;
        Uri uriSaveImage = null;
        uriSaveImage = null;
        uriSaveImage = null;
        ByteArrayInputStream byteArrayInputStream2 = null;
        try {
            try {
                byteArrayInputStream = new ByteArrayInputStream(byteArrayOutputStream.toByteArray());
            } catch (IOException e) {
                Logger.error(getLogTag(), UNABLE_TO_PROCESS_IMAGE, e);
            }
        } catch (IOException unused) {
            byteArrayInputStream = null;
        } catch (Throwable th) {
            th = th;
        }
        try {
            uriSaveImage = saveImage(uri, byteArrayInputStream);
            byteArrayInputStream.close();
        } catch (IOException unused2) {
            if (byteArrayInputStream != null) {
                byteArrayInputStream.close();
            }
            return uriSaveImage;
        } catch (Throwable th2) {
            th = th2;
            byteArrayInputStream2 = byteArrayInputStream;
            if (byteArrayInputStream2 != null) {
                try {
                    byteArrayInputStream2.close();
                } catch (IOException e2) {
                    Logger.error(getLogTag(), UNABLE_TO_PROCESS_IMAGE, e2);
                }
            }
            throw th;
        }
        return uriSaveImage;
    }

    private Bitmap prepareBitmap(Bitmap bitmap, Uri uri, ExifWrapper exifWrapper) throws IOException {
        if (this.settings.isShouldCorrectOrientation()) {
            bitmap = replaceBitmap(bitmap, ImageUtils.correctOrientation(getContext(), bitmap, uri, exifWrapper));
        }
        return this.settings.isShouldResize() ? replaceBitmap(bitmap, ImageUtils.resize(bitmap, this.settings.getWidth(), this.settings.getHeight())) : bitmap;
    }

    private Bitmap replaceBitmap(Bitmap bitmap, Bitmap bitmap2) {
        if (bitmap != bitmap2) {
            bitmap.recycle();
        }
        return bitmap2;
    }

    private void returnDataUrl(PluginCall pluginCall, ExifWrapper exifWrapper, ByteArrayOutputStream byteArrayOutputStream) {
        String strEncodeToString = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2);
        JSObject jSObject = new JSObject();
        jSObject.put("format", "jpeg");
        jSObject.put("dataUrl", "data:image/jpeg;base64," + strEncodeToString);
        jSObject.put("exif", (Object) exifWrapper.toJson());
        pluginCall.resolve(jSObject);
    }

    private void returnBase64(PluginCall pluginCall, ExifWrapper exifWrapper, ByteArrayOutputStream byteArrayOutputStream) {
        String strEncodeToString = Base64.encodeToString(byteArrayOutputStream.toByteArray(), 2);
        JSObject jSObject = new JSObject();
        jSObject.put("format", "jpeg");
        jSObject.put("base64String", strEncodeToString);
        jSObject.put("exif", (Object) exifWrapper.toJson());
        pluginCall.resolve(jSObject);
    }

    @Override // com.getcapacitor.Plugin
    @PluginMethod
    public void requestPermissions(PluginCall pluginCall) {
        List list;
        if (isPermissionDeclared("camera")) {
            super.requestPermissions(pluginCall);
            return;
        }
        JSArray array = pluginCall.getArray("permissions");
        if (array != null) {
            try {
                list = array.toList();
            } catch (JSONException unused) {
                list = null;
            }
        } else {
            list = null;
        }
        if (list != null && list.size() == 1 && (list.contains("camera") || list.contains(PHOTOS))) {
            checkPermissions(pluginCall);
        } else {
            requestPermissionForAlias(SAVE_GALLERY, pluginCall, "checkPermissions");
        }
    }

    @Override // com.getcapacitor.Plugin
    public Map<String, PermissionState> getPermissionStates() {
        Map<String, PermissionState> permissionStates = super.getPermissionStates();
        if (!isPermissionDeclared("camera")) {
            permissionStates.put("camera", PermissionState.GRANTED);
        }
        if (permissionStates.containsKey(PHOTOS)) {
            permissionStates.put(PHOTOS, PermissionState.GRANTED);
        }
        if (Build.VERSION.SDK_INT >= 30 && permissionStates.containsKey(READ_EXTERNAL_STORAGE)) {
            permissionStates.put(SAVE_GALLERY, permissionStates.get(READ_EXTERNAL_STORAGE));
        }
        return permissionStates;
    }

    private void editImage(PluginCall pluginCall, Uri uri, ByteArrayOutputStream byteArrayOutputStream) {
        try {
            Intent intentCreateEditIntent = createEditIntent(getTempImage(uri, byteArrayOutputStream));
            if (intentCreateEditIntent != null) {
                startActivityForResult(pluginCall, intentCreateEditIntent, "processEditedImage");
            } else {
                pluginCall.reject(IMAGE_EDIT_ERROR);
            }
        } catch (Exception e) {
            pluginCall.reject(IMAGE_EDIT_ERROR, e);
        }
    }

    private Intent createEditIntent(Uri uri) {
        List<ResolveInfo> listLegacyQueryIntentActivities;
        try {
            File file = new File(uri.getPath());
            Uri uriForFile = FileProvider.getUriForFile(getActivity(), getContext().getPackageName() + ".fileprovider", file);
            Intent intent = new Intent("android.intent.action.EDIT");
            intent.setDataAndType(uriForFile, "image/*");
            this.imageEditedFileSavePath = file.getAbsolutePath();
            intent.addFlags(3);
            intent.putExtra("output", uriForFile);
            if (Build.VERSION.SDK_INT >= 33) {
                listLegacyQueryIntentActivities = getContext().getPackageManager().queryIntentActivities(intent, PackageManager.ResolveInfoFlags.of(65536L));
            } else {
                listLegacyQueryIntentActivities = legacyQueryIntentActivities(intent);
            }
            Iterator<ResolveInfo> it = listLegacyQueryIntentActivities.iterator();
            while (it.hasNext()) {
                getContext().grantUriPermission(it.next().activityInfo.packageName, uriForFile, 3);
            }
            return intent;
        } catch (Exception unused) {
            return null;
        }
    }

    private List<ResolveInfo> legacyQueryIntentActivities(Intent intent) {
        return getContext().getPackageManager().queryIntentActivities(intent, 65536);
    }

    @Override // com.getcapacitor.Plugin
    protected Bundle saveInstanceState() {
        Bundle bundleSaveInstanceState = super.saveInstanceState();
        if (bundleSaveInstanceState != null) {
            bundleSaveInstanceState.putString("cameraImageFileSavePath", this.imageFileSavePath);
        }
        return bundleSaveInstanceState;
    }

    @Override // com.getcapacitor.Plugin
    protected void restoreState(Bundle bundle) {
        String string = bundle.getString("cameraImageFileSavePath");
        if (string != null) {
            this.imageFileSavePath = string;
        }
    }

    @Override // com.getcapacitor.Plugin
    protected void handleOnDestroy() {
        ActivityResultLauncher<PickVisualMediaRequest> activityResultLauncher = this.pickMedia;
        if (activityResultLauncher != null) {
            activityResultLauncher.unregister();
        }
        ActivityResultLauncher<PickVisualMediaRequest> activityResultLauncher2 = this.pickMultipleMedia;
        if (activityResultLauncher2 != null) {
            activityResultLauncher2.unregister();
        }
    }
}
