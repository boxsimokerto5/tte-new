package com.capacitorjs.plugins.camera;

/* JADX INFO: loaded from: classes.dex */
public class CameraSettings {
    public static final boolean DEFAULT_CORRECT_ORIENTATION = true;
    public static final int DEFAULT_QUALITY = 90;
    public static final boolean DEFAULT_SAVE_IMAGE_TO_GALLERY = false;
    private CameraResultType resultType = CameraResultType.BASE64;
    private int quality = 90;
    private boolean shouldResize = false;
    private boolean shouldCorrectOrientation = true;
    private boolean saveToGallery = false;
    private boolean allowEditing = false;
    private int width = 0;
    private int height = 0;
    private CameraSource source = CameraSource.PROMPT;

    public int getHeight() {
        return this.height;
    }

    public int getQuality() {
        return this.quality;
    }

    public CameraResultType getResultType() {
        return this.resultType;
    }

    public CameraSource getSource() {
        return this.source;
    }

    public int getWidth() {
        return this.width;
    }

    public boolean isAllowEditing() {
        return this.allowEditing;
    }

    public boolean isSaveToGallery() {
        return this.saveToGallery;
    }

    public boolean isShouldCorrectOrientation() {
        return this.shouldCorrectOrientation;
    }

    public boolean isShouldResize() {
        return this.shouldResize;
    }

    public void setAllowEditing(boolean z) {
        this.allowEditing = z;
    }

    public void setHeight(int i) {
        this.height = i;
    }

    public void setQuality(int i) {
        this.quality = i;
    }

    public void setResultType(CameraResultType cameraResultType) {
        this.resultType = cameraResultType;
    }

    public void setSaveToGallery(boolean z) {
        this.saveToGallery = z;
    }

    public void setShouldCorrectOrientation(boolean z) {
        this.shouldCorrectOrientation = z;
    }

    public void setShouldResize(boolean z) {
        this.shouldResize = z;
    }

    public void setSource(CameraSource cameraSource) {
        this.source = cameraSource;
    }

    public void setWidth(int i) {
        this.width = i;
    }
}
