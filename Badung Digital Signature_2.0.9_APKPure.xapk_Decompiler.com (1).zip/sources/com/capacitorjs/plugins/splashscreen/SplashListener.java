package com.capacitorjs.plugins.splashscreen;

/* JADX INFO: loaded from: classes.dex */
public interface SplashListener {
    void completed();

    void error();
}
