package com.capacitorjs.plugins.splashscreen;

import android.widget.ImageView;
import androidx.recyclerview.widget.ItemTouchHelper;
import com.google.firebase.messaging.ServiceStarter;

/* JADX INFO: loaded from: classes.dex */
public class SplashScreenConfig {
    private Integer backgroundColor;
    private String layoutName;
    private Integer spinnerColor;
    private Integer spinnerStyle;
    private boolean showSpinner = false;
    private Integer launchShowDuration = Integer.valueOf(ServiceStarter.ERROR_UNKNOWN);
    private boolean launchAutoHide = true;
    private Integer launchFadeInDuration = 0;
    private Integer launchFadeOutDuration = Integer.valueOf(ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
    private String resourceName = "splash";
    private boolean immersive = false;
    private boolean fullScreen = false;
    private ImageView.ScaleType scaleType = ImageView.ScaleType.FIT_XY;
    private boolean usingDialog = false;

    public Integer getBackgroundColor() {
        return this.backgroundColor;
    }

    public Integer getLaunchFadeInDuration() {
        return this.launchFadeInDuration;
    }

    public Integer getLaunchFadeOutDuration() {
        return this.launchFadeOutDuration;
    }

    public Integer getLaunchShowDuration() {
        return this.launchShowDuration;
    }

    public String getLayoutName() {
        return this.layoutName;
    }

    public String getResourceName() {
        return this.resourceName;
    }

    public ImageView.ScaleType getScaleType() {
        return this.scaleType;
    }

    public Integer getSpinnerColor() {
        return this.spinnerColor;
    }

    public Integer getSpinnerStyle() {
        return this.spinnerStyle;
    }

    public boolean isFullScreen() {
        return this.fullScreen;
    }

    public boolean isImmersive() {
        return this.immersive;
    }

    public boolean isLaunchAutoHide() {
        return this.launchAutoHide;
    }

    public boolean isShowSpinner() {
        return this.showSpinner;
    }

    public boolean isUsingDialog() {
        return this.usingDialog;
    }

    public void setBackgroundColor(Integer num) {
        this.backgroundColor = num;
    }

    public void setFullScreen(boolean z) {
        this.fullScreen = z;
    }

    public void setImmersive(boolean z) {
        this.immersive = z;
    }

    public void setLaunchAutoHide(boolean z) {
        this.launchAutoHide = z;
    }

    public void setLaunchFadeOutDuration(Integer num) {
        this.launchFadeOutDuration = num;
    }

    public void setLaunchShowDuration(Integer num) {
        this.launchShowDuration = num;
    }

    public void setLayoutName(String str) {
        this.layoutName = str;
    }

    public void setResourceName(String str) {
        this.resourceName = str;
    }

    public void setScaleType(ImageView.ScaleType scaleType) {
        this.scaleType = scaleType;
    }

    public void setShowSpinner(boolean z) {
        this.showSpinner = z;
    }

    public void setSpinnerColor(Integer num) {
        this.spinnerColor = num;
    }

    public void setSpinnerStyle(Integer num) {
        this.spinnerStyle = num;
    }

    public void setUsingDialog(boolean z) {
        this.usingDialog = z;
    }
}
