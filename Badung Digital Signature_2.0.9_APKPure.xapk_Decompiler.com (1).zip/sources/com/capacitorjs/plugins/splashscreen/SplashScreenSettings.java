package com.capacitorjs.plugins.splashscreen;

import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.vectordrawable.graphics.drawable.PathInterpolatorCompat;

/* JADX INFO: loaded from: classes.dex */
public class SplashScreenSettings {
    private boolean autoHide;
    private Integer fadeInDuration;
    private Integer fadeOutDuration;
    private Integer showDuration = Integer.valueOf(PathInterpolatorCompat.MAX_NUM_POINTS);

    public Integer getFadeInDuration() {
        return this.fadeInDuration;
    }

    public Integer getFadeOutDuration() {
        return this.fadeOutDuration;
    }

    public Integer getShowDuration() {
        return this.showDuration;
    }

    public boolean isAutoHide() {
        return this.autoHide;
    }

    public void setAutoHide(boolean z) {
        this.autoHide = z;
    }

    public void setFadeInDuration(Integer num) {
        this.fadeInDuration = num;
    }

    public void setFadeOutDuration(Integer num) {
        this.fadeOutDuration = num;
    }

    public void setShowDuration(Integer num) {
        this.showDuration = num;
    }

    public SplashScreenSettings() {
        Integer numValueOf = Integer.valueOf(ItemTouchHelper.Callback.DEFAULT_DRAG_ANIMATION_DURATION);
        this.fadeInDuration = numValueOf;
        this.fadeOutDuration = numValueOf;
        this.autoHide = true;
    }
}
