package com.capacitorjs.plugins.splashscreen;

/* JADX INFO: loaded from: classes.dex */
public final class R {

    public static final class style {
        public static int capacitor_default_style = 0x7f13046e;
        public static int capacitor_full_screen_style = 0x7f13046f;
        public static int capacitor_immersive_style = 0x7f130470;

        private style() {
        }
    }

    private R() {
    }
}
