package com.journeyapps.barcodescanner.camera;

import android.hardware.Camera;

/* JADX INFO: loaded from: classes.dex */
public interface CameraParametersCallback {
    Camera.Parameters changeCameraParameters(Camera.Parameters parameters);
}
